v 0.4.0
- 根据sdk规范做了调整
- 精简接口，默认去掉checkAppUri接口用openAppUri代替
- 精简接口，默认去掉appname,使用packagename 代替
- 去掉lastestAppUri接口，会根据packagename 向as请求版本信息

v 0.3.0

- 修复了针对不支持本地存储情况，如快拍浏览器内置浏览器 - 修复某些情况不能下载问题

v 0.2.0

- 调整优化结构，使得稍微通用点
- 把onload时候检查是否安装app，改为触发时候再检查。

v 0.1.0

- 初始化版本
